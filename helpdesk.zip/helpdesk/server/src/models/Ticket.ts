// models/Ticket.ts
// Mongoose schema + TypeScript interface for the Ticket document

import { Schema, model, Document } from "mongoose";

// ──────────────────────────────────────────────
// TypeScript Interface
// ──────────────────────────────────────────────
export interface ITicket extends Document {
  ticketId: string;
  subject: string;
  description: string;
  priority: "Low" | "Medium" | "High";
  status: "Open" | "In Progress" | "Closed";
  createdAt: Date;
}

// ──────────────────────────────────────────────
// Mongoose Schema
// ──────────────────────────────────────────────
const TicketSchema = new Schema<ITicket>(
  {
    ticketId: {
      type: String,
      required: [true, "Ticket ID is required"],
      unique: true,
      default: () => `TKT-${Date.now()}`, // auto-generate a ticket ID
    },
    subject: {
      type: String,
      required: [true, "Subject is required"],
      trim: true,
      maxlength: [120, "Subject cannot exceed 120 characters"],
    },
    description: {
      type: String,
      required: [true, "Description is required"],
      trim: true,
      maxlength: [1000, "Description cannot exceed 1000 characters"],
    },
    priority: {
      type: String,
      enum: {
        values: ["Low", "Medium", "High"],
        message: "Priority must be Low, Medium, or High",
      },
      required: [true, "Priority is required"],
    },
    status: {
      type: String,
      enum: {
        values: ["Open", "In Progress", "Closed"],
        message: "Status must be Open, In Progress, or Closed",
      },
      default: "Open",
    },
  },
  {
    timestamps: { createdAt: true, updatedAt: false }, // only track createdAt
  }
);

export const Ticket = model<ITicket>("Ticket", TicketSchema);
