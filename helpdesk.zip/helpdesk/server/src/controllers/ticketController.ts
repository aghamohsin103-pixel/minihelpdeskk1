// controllers/ticketController.ts
// Business logic for all ticket-related API operations

import { Request, Response } from "express";
import { Ticket } from "../models/Ticket";

// Valid priority values – used for validation
const VALID_PRIORITIES = ["Low", "Medium", "High"] as const;
type Priority = (typeof VALID_PRIORITIES)[number];

// ──────────────────────────────────────────────
// GET /tickets
// Optional query param: ?priority=Low|Medium|High
// Returns all tickets, or filtered by priority
// ──────────────────────────────────────────────
export const getAllTickets = async (req: Request, res: Response): Promise<void> => {
  try {
    const { priority } = req.query;

    // Validate priority query param if provided
    if (priority !== undefined) {
      if (!VALID_PRIORITIES.includes(priority as Priority)) {
        res.status(400).json({
          message: `Invalid priority value. Must be one of: ${VALID_PRIORITIES.join(", ")}`,
        });
        return;
      }
    }

    // Build query: filter by priority if given, otherwise fetch all
    const query = priority ? { priority: priority as Priority } : {};
    const tickets = await Ticket.find(query).sort({ createdAt: -1 }); // newest first

    res.status(200).json(tickets);
  } catch (error) {
    console.error("[GET /tickets] Error:", error);
    res.status(500).json({ message: "Internal server error while fetching tickets." });
  }
};

// ──────────────────────────────────────────────
// POST /tickets
// Creates a new ticket from request body
// ──────────────────────────────────────────────
export const createTicket = async (req: Request, res: Response): Promise<void> => {
  try {
    const { subject, description, priority, status } = req.body;

    // Basic presence validation
    if (!subject || !description || !priority) {
      res.status(400).json({ message: "subject, description, and priority are required fields." });
      return;
    }

    // Validate priority value
    if (!VALID_PRIORITIES.includes(priority as Priority)) {
      res.status(400).json({
        message: `Invalid priority. Allowed values: ${VALID_PRIORITIES.join(", ")}`,
      });
      return;
    }

    const newTicket = new Ticket({
      subject,
      description,
      priority,
      status: status || "Open", // default to Open if not provided
    });

    const savedTicket = await newTicket.save();
    res.status(201).json(savedTicket);
  } catch (error: unknown) {
    console.error("[POST /tickets] Error:", error);

    // Mongoose validation error
    if (
      error !== null &&
      typeof error === "object" &&
      "name" in error &&
      (error as { name: string }).name === "ValidationError"
    ) {
      res.status(400).json({ message: (error as Error).message });
      return;
    }

    res.status(500).json({ message: "Internal server error while creating ticket." });
  }
};

// ──────────────────────────────────────────────
// DELETE /tickets/:id
// Deletes a ticket by its MongoDB _id
// ──────────────────────────────────────────────
export const deleteTicket = async (req: Request, res: Response): Promise<void> => {
  try {
    const { id } = req.params;

    const deleted = await Ticket.findByIdAndDelete(id);

    if (!deleted) {
      res.status(404).json({ message: `Ticket with id '${id}' not found.` });
      return;
    }

    res.status(200).json({ message: "Ticket deleted successfully.", id });
  } catch (error) {
    console.error("[DELETE /tickets/:id] Error:", error);
    res.status(500).json({ message: "Internal server error while deleting ticket." });
  }
};
