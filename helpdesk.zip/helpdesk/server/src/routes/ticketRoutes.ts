// routes/ticketRoutes.ts
// Express router – maps HTTP methods + paths to controller functions

import { Router } from "express";
import {
  getAllTickets,
  createTicket,
  deleteTicket,
} from "../controllers/ticketController";

const router = Router();

// GET  /tickets          → list all (with optional ?priority= filter)
// POST /tickets          → create new ticket
router.route("/").get(getAllTickets).post(createTicket);

// DELETE /tickets/:id    → delete by MongoDB _id
router.route("/:id").delete(deleteTicket);

export default router;
