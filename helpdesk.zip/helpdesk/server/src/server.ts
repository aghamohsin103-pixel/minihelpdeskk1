// server.ts
// Express application entry point — connects to MongoDB and starts HTTP server

import express, { Application, Request, Response, NextFunction } from "express";
import cors from "cors";
import dotenv from "dotenv";
import mongoose from "mongoose";
import ticketRoutes from "./routes/ticketRoutes";

// Load environment variables from .env file
dotenv.config();

const app: Application = express();
const PORT = process.env.PORT || 5000;
const MONGO_URI = process.env.MONGO_URI || "";

// ──────────────────────────────────────────────
// Global Middleware
// ──────────────────────────────────────────────
app.use(cors()); // Allow cross-origin requests from the React frontend
app.use(express.json()); // Parse incoming JSON bodies
app.use(express.urlencoded({ extended: true }));

// ──────────────────────────────────────────────
// API Routes
// ──────────────────────────────────────────────
app.use("/tickets", ticketRoutes);

// Health check endpoint
app.get("/health", (_req: Request, res: Response) => {
  res.status(200).json({ status: "ok", message: "MiniHelpDesk API is running." });
});

// 404 handler – catch any unmatched routes
app.use((_req: Request, res: Response) => {
  res.status(404).json({ message: "Route not found." });
});

// Global error handler – catches errors passed via next(err)
app.use((err: Error, _req: Request, res: Response, _next: NextFunction) => {
  console.error("[Global Error Handler]", err.message);
  res.status(500).json({ message: err.message || "An unexpected error occurred." });
});

// ──────────────────────────────────────────────
// MongoDB Connection + Server Start
// ──────────────────────────────────────────────
if (!MONGO_URI) {
  console.error("❌  MONGO_URI is not defined in .env — server cannot start.");
  process.exit(1);
}

mongoose
  .connect(MONGO_URI)
  .then(() => {
    console.log("✅  MongoDB connected successfully.");
    app.listen(PORT, () => {
      console.log(`🚀  Server running on http://localhost:${PORT}`);
    });
  })
  .catch((error: Error) => {
    console.error("❌  MongoDB connection failed:", error.message);
    process.exit(1);
  });
