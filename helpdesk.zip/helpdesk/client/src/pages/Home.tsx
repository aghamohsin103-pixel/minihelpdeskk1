// pages/Home.tsx
// Main page: ticket form (left), filtered ticket list (right)
// Orchestrates all API calls via Axios and manages state

import React, { useState, useEffect, useCallback } from "react";
import api from "../api/axiosInstance";
import TicketForm from "../components/TicketForm";
import TicketList from "../components/TicketList";
import PriorityFilter from "../components/PriorityFilter";
import GlobalErrorPage from "../components/GlobalErrorPage";
import type { Ticket, CreateTicketPayload, Priority } from "../types/ticket";
import { AxiosError } from "axios";

type FilterValue = Priority | "All";

const Home: React.FC = () => {
  // ── State ────────────────────────────────────
  const [tickets, setTickets]           = useState<Ticket[]>([]);
  const [filter, setFilter]             = useState<FilterValue>("All");
  const [isLoading, setIsLoading]       = useState(false);
  const [listError, setListError]       = useState<string | null>(null);
  const [formLoading, setFormLoading]   = useState(false);
  const [formError, setFormError]       = useState<string | null>(null);
  const [formSuccess, setFormSuccess]   = useState(false);
  const [deletingId, setDeletingId]     = useState<string | null>(null);
  const [fatalError, setFatalError]     = useState(false);

  // ── Fetch Tickets ────────────────────────────
  const fetchTickets = useCallback(async (priorityFilter: FilterValue) => {
    setIsLoading(true);
    setListError(null);
    try {
      const params = priorityFilter !== "All" ? { priority: priorityFilter } : {};
      const { data } = await api.get<Ticket[]>("/tickets", { params });
      setTickets(data);
    } catch (err) {
      const error = err as AxiosError<{ message: string }>;
      if (!error.response) {
        // Network error — backend likely offline
        setFatalError(true);
        return;
      }
      setListError(
        error.response?.data?.message || "Failed to load tickets. Please try again."
      );
    } finally {
      setIsLoading(false);
    }
  }, []);

  // Refetch whenever the filter changes
  useEffect(() => {
    fetchTickets(filter);
  }, [filter, fetchTickets]);

  // ── Create Ticket ────────────────────────────
  const handleCreate = async (payload: CreateTicketPayload): Promise<void> => {
    setFormLoading(true);
    setFormError(null);
    setFormSuccess(false);
    try {
      const { data } = await api.post<Ticket>("/tickets", payload);
      // Prepend new ticket to list (if it matches current filter)
      if (filter === "All" || filter === data.priority) {
        setTickets((prev) => [data, ...prev]);
      }
      setFormSuccess(true);
      setTimeout(() => setFormSuccess(false), 3000); // auto-dismiss
    } catch (err) {
      const error = err as AxiosError<{ message: string }>;
      if (!error.response) {
        setFatalError(true);
        return;
      }
      setFormError(
        error.response?.data?.message || "Failed to create ticket. Please try again."
      );
    } finally {
      setFormLoading(false);
    }
  };

  // ── Delete Ticket ────────────────────────────
  const handleDelete = async (id: string): Promise<void> => {
    setDeletingId(id);
    try {
      await api.delete(`/tickets/${id}`);
      setTickets((prev) => prev.filter((t) => t._id !== id));
    } catch (err) {
      const error = err as AxiosError<{ message: string }>;
      if (!error.response) {
        setFatalError(true);
        return;
      }
      alert(error.response?.data?.message || "Failed to delete ticket.");
    } finally {
      setDeletingId(null);
    }
  };

  // ── Fatal error: show global error page ──────
  if (fatalError) {
    return (
      <GlobalErrorPage
        message="Cannot reach the server. Make sure the backend is running on http://localhost:5000"
        onReload={() => { setFatalError(false); fetchTickets(filter); }}
      />
    );
  }

  // ── Render ───────────────────────────────────
  return (
    <div className="min-h-screen">
      {/* ── Header ── */}
      <header className="border-b border-white/5 bg-white/[0.02] backdrop-blur-sm sticky top-0 z-10">
        <div className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-brand-600 flex items-center justify-center text-sm">
              🎫
            </div>
            <div>
              <h1 className="font-display text-lg text-white leading-none">MiniHelpDesk</h1>
              <p className="text-[10px] text-slate-500 font-mono mt-0.5">Ticket System</p>
            </div>
          </div>
          <div className="text-right hidden sm:block">
            <p className="text-xs text-slate-400 font-medium">BSCS VIB · Web Technologies I</p>
            <p className="text-[10px] text-slate-600 mt-0.5">
              Abdul Rehman Shaikh &amp; Mohsin Mustafa
            </p>
          </div>
        </div>
      </header>

      {/* ── Main layout ── */}
      <main className="max-w-6xl mx-auto px-6 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">

          {/* ── Left: Create Ticket Form ── */}
          <aside className="lg:col-span-2">
            <div className="glass rounded-2xl p-6 sticky top-24">
              <div className="mb-5">
                <h2 className="font-display text-xl text-white">New Ticket</h2>
                <p className="text-xs text-slate-500 mt-1">
                  Fill in the details below to submit a support ticket.
                </p>
              </div>

              {/* Success toast */}
              {formSuccess && (
                <div className="mb-4 flex items-center gap-2 px-4 py-3 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-medium">
                  <svg className="w-4 h-4 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                  </svg>
                  Ticket created successfully!
                </div>
              )}

              {/* Form-level error */}
              {formError && (
                <div className="mb-4 flex items-center gap-2 px-4 py-3 rounded-xl bg-red-500/10 border border-red-500/20 text-red-400 text-xs font-medium">
                  <svg className="w-4 h-4 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  {formError}
                </div>
              )}

              <TicketForm onSubmit={handleCreate} isLoading={formLoading} />
            </div>
          </aside>

          {/* ── Right: Ticket List ── */}
          <section className="lg:col-span-3">
            {/* List header + filter */}
            <div className="flex flex-wrap items-center justify-between gap-4 mb-5">
              <div>
                <h2 className="font-display text-xl text-white">
                  Tickets
                  {!isLoading && (
                    <span className="ml-2 text-sm text-slate-500 font-body">
                      ({tickets.length})
                    </span>
                  )}
                </h2>
              </div>
              <PriorityFilter
                value={filter}
                onChange={setFilter}
                disabled={isLoading}
              />
            </div>

            <TicketList
              tickets={tickets}
              isLoading={isLoading}
              error={listError}
              onDelete={handleDelete}
              deletingId={deletingId}
            />
          </section>
        </div>
      </main>

      {/* ── Footer ── */}
      <footer className="border-t border-white/5 mt-16 py-6 text-center">
        <p className="text-xs text-slate-600">
          MiniHelpDesk · BSCS VIB · Web Technologies I &nbsp;|&nbsp;
          Abdul Rehman Shaikh &amp; Mohsin Mustafa
        </p>
      </footer>
    </div>
  );
};

export default Home;
