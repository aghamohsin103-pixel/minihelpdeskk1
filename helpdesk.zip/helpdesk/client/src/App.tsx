// App.tsx
// Root component — wraps routes with ErrorBoundary for global crash handling

import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import ErrorBoundary from "./components/ErrorBoundary";
import Home from "./pages/Home";
import GlobalErrorPage from "./components/GlobalErrorPage";

const App: React.FC = () => {
  return (
    // ErrorBoundary wraps the entire app — catches any JS runtime crash
    <ErrorBoundary>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Home />} />
          {/* 404 fallback */}
          <Route
            path="*"
            element={
              <GlobalErrorPage
                message="Page not found. Navigate back to the home page."
                onReload={() => (window.location.href = "/")}
              />
            }
          />
        </Routes>
      </BrowserRouter>
    </ErrorBoundary>
  );
};

export default App;
