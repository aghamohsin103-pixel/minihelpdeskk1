// components/GlobalErrorPage.tsx
// Friendly full-page error UI shown when backend is offline, fetch fails, or JS crashes

import React from "react";

interface Props {
  onReload?: () => void;
  message?: string;
}

const GlobalErrorPage: React.FC<Props> = ({
  onReload = () => window.location.reload(),
  message,
}) => {
  return (
    <div className="min-h-screen flex items-center justify-center px-4">
      {/* Glow blob behind the card */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <div className="w-96 h-96 rounded-full bg-red-600/10 blur-3xl" />
      </div>

      <div className="relative glass rounded-2xl p-10 max-w-md w-full text-center shadow-2xl">
        {/* Icon */}
        <div className="mb-6 flex justify-center">
          <div className="w-20 h-20 rounded-full bg-red-500/10 border border-red-500/30 flex items-center justify-center">
            <span className="text-4xl">😕</span>
          </div>
        </div>

        {/* Heading */}
        <h1 className="font-display text-3xl text-white mb-3">
          Something went wrong
        </h1>

        {/* Description */}
        <p className="text-slate-400 text-sm leading-relaxed mb-2">
          {message ||
            "We couldn't connect to the server or an unexpected error occurred."}
        </p>
        <p className="text-slate-500 text-xs mb-8">
          Please check your network connection or try again shortly.
        </p>

        {/* Reload button */}
        <button
          onClick={onReload}
          className="
            inline-flex items-center gap-2 px-6 py-3 rounded-xl
            bg-brand-600 hover:bg-brand-500 text-white font-medium text-sm
            transition-all duration-200 hover:shadow-lg hover:shadow-brand-600/25
            active:scale-95
          "
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            className="w-4 h-4"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
            strokeWidth={2}
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"
            />
          </svg>
          Reload Page
        </button>
      </div>
    </div>
  );
};

export default GlobalErrorPage;
