// components/ErrorBoundary.tsx
// React class-based Error Boundary that catches JS crashes and renders GlobalErrorPage

import { Component, ErrorInfo, ReactNode } from "react";
import GlobalErrorPage from "./GlobalErrorPage";

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

class ErrorBoundary extends Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  // Triggered when a descendant component throws during rendering
  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  // Log the error details (could also send to a logging service)
  componentDidCatch(error: Error, info: ErrorInfo): void {
    console.error("[ErrorBoundary] Caught error:", error, info.componentStack);
  }

  // Reset boundary so the user can retry
  handleReset = (): void => {
    this.setState({ hasError: false, error: null });
    window.location.reload();
  };

  render(): ReactNode {
    if (this.state.hasError) {
      return <GlobalErrorPage onReload={this.handleReset} />;
    }
    return this.props.children;
  }
}

export default ErrorBoundary;
