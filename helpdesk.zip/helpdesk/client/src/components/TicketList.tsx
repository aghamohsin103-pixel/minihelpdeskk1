// components/TicketList.tsx
// Renders the list of tickets with loading, empty, and error states
// Each ticket card has a delete button

import React from "react";
import type { Ticket, Priority, Status } from "../types/ticket";

interface Props {
  tickets: Ticket[];
  isLoading: boolean;
  error: string | null;
  onDelete: (id: string) => void;
  deletingId: string | null; // tracks which ticket is being deleted
}

// ── Badge helpers ─────────────────────────────
const PRIORITY_BADGE: Record<Priority, string> = {
  Low:    "bg-emerald-500/15 text-emerald-400 border border-emerald-500/30",
  Medium: "bg-amber-500/15   text-amber-400   border border-amber-500/30",
  High:   "bg-red-500/15     text-red-400     border border-red-500/30",
};

const PRIORITY_DOT: Record<Priority, string> = {
  Low:    "bg-emerald-400",
  Medium: "bg-amber-400",
  High:   "bg-red-400",
};

const STATUS_BADGE: Record<Status, string> = {
  "Open":        "bg-brand-500/15 text-brand-300 border border-brand-500/30",
  "In Progress": "bg-violet-500/15 text-violet-300 border border-violet-500/30",
  "Closed":      "bg-slate-500/15 text-slate-400 border border-slate-500/30",
};

// Format ISO date to a readable string
const formatDate = (iso: string): string => {
  return new Date(iso).toLocaleDateString("en-US", {
    day:   "numeric",
    month: "short",
    year:  "numeric",
  });
};

// ── Loading skeleton ──────────────────────────
const SkeletonCard = () => (
  <div className="glass rounded-2xl p-5 animate-pulse">
    <div className="flex justify-between mb-3">
      <div className="h-3 bg-white/10 rounded w-20" />
      <div className="h-3 bg-white/10 rounded w-14" />
    </div>
    <div className="h-4 bg-white/10 rounded w-3/4 mb-2" />
    <div className="h-3 bg-white/5 rounded w-full mb-1" />
    <div className="h-3 bg-white/5 rounded w-2/3" />
  </div>
);

// ── Main component ────────────────────────────
const TicketList: React.FC<Props> = ({
  tickets,
  isLoading,
  error,
  onDelete,
  deletingId,
}) => {
  // Loading state — show skeleton cards
  if (isLoading) {
    return (
      <div className="space-y-3">
        {[1, 2, 3].map((n) => <SkeletonCard key={n} />)}
      </div>
    );
  }

  // Error state
  if (error) {
    return (
      <div className="glass rounded-2xl p-8 text-center border-red-500/20">
        <div className="text-3xl mb-3">⚠️</div>
        <p className="text-red-400 font-medium text-sm">{error}</p>
        <p className="text-slate-500 text-xs mt-1">Check if the backend server is running.</p>
      </div>
    );
  }

  // Empty state
  if (tickets.length === 0) {
    return (
      <div className="glass rounded-2xl p-12 text-center">
        <div className="text-4xl mb-4">🎫</div>
        <p className="text-slate-300 font-medium">No tickets found</p>
        <p className="text-slate-500 text-xs mt-1">
          Create a ticket using the form, or adjust the priority filter.
        </p>
      </div>
    );
  }

  // Ticket cards
  return (
    <div className="space-y-3">
      {tickets.map((ticket) => (
        <div
          key={ticket._id}
          className="
            glass rounded-2xl p-5 hover:border-white/20
            transition-all duration-200 hover:shadow-lg hover:shadow-black/20
            group
          "
        >
          {/* Top row: ticketId, status, priority */}
          <div className="flex flex-wrap items-center gap-2 mb-3">
            <span className="font-mono text-xs text-slate-500">{ticket.ticketId}</span>
            <span className="text-slate-700">•</span>

            {/* Status badge */}
            <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${STATUS_BADGE[ticket.status]}`}>
              {ticket.status}
            </span>

            {/* Priority badge */}
            <span className={`text-xs px-2 py-0.5 rounded-full font-medium flex items-center gap-1.5 ${PRIORITY_BADGE[ticket.priority]}`}>
              <span className={`inline-block w-1.5 h-1.5 rounded-full ${PRIORITY_DOT[ticket.priority]}`} />
              {ticket.priority}
            </span>

            {/* Date — pushed to the right */}
            <span className="ml-auto text-xs text-slate-500">
              {formatDate(ticket.createdAt)}
            </span>
          </div>

          {/* Subject */}
          <h3 className="text-sm font-semibold text-slate-100 mb-1.5 leading-snug">
            {ticket.subject}
          </h3>

          {/* Description */}
          <p className="text-xs text-slate-400 leading-relaxed line-clamp-2 mb-4">
            {ticket.description}
          </p>

          {/* Delete button */}
          <div className="flex justify-end">
            <button
              onClick={() => onDelete(ticket._id)}
              disabled={deletingId === ticket._id}
              className="
                flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium
                text-red-400/70 hover:text-red-400 hover:bg-red-500/10
                border border-transparent hover:border-red-500/20
                disabled:opacity-40 disabled:cursor-not-allowed
                transition-all duration-150
                opacity-0 group-hover:opacity-100
              "
              aria-label={`Delete ticket ${ticket.ticketId}`}
            >
              {deletingId === ticket._id ? (
                <>
                  <svg className="animate-spin w-3.5 h-3.5" viewBox="0 0 24 24" fill="none">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z" />
                  </svg>
                  Deleting…
                </>
              ) : (
                <>
                  <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                  </svg>
                  Delete
                </>
              )}
            </button>
          </div>
        </div>
      ))}
    </div>
  );
};

export default TicketList;
