// components/PriorityFilter.tsx
// Dropdown filter above the ticket list — calls back with the selected priority

import React from "react";
import type { Priority } from "../types/ticket";

// "All" sentinel value means no filter
type FilterValue = Priority | "All";

interface Props {
  value: FilterValue;
  onChange: (value: FilterValue) => void;
  disabled?: boolean;
}

const OPTIONS: { label: string; value: FilterValue }[] = [
  { label: "All Priorities", value: "All" },
  { label: "🟢  Low",        value: "Low" },
  { label: "🟡  Medium",     value: "Medium" },
  { label: "🔴  High",       value: "High" },
];

const PriorityFilter: React.FC<Props> = ({ value, onChange, disabled = false }) => {
  return (
    <div className="flex items-center gap-3">
      <label
        htmlFor="priority-filter"
        className="text-xs font-medium text-slate-400 uppercase tracking-widest whitespace-nowrap"
      >
        Filter by
      </label>

      <div className="relative">
        <select
          id="priority-filter"
          value={value}
          disabled={disabled}
          onChange={(e) => onChange(e.target.value as FilterValue)}
          className="
            appearance-none glass rounded-xl px-4 py-2 pr-9
            text-sm font-medium text-slate-200 cursor-pointer
            border border-white/10 hover:border-white/25
            focus:outline-none focus:ring-2 focus:ring-brand-500/50
            disabled:opacity-40 disabled:cursor-not-allowed
            transition-all duration-150
          "
        >
          {OPTIONS.map((opt) => (
            <option key={opt.value} value={opt.value} className="bg-slate-900 text-slate-100">
              {opt.label}
            </option>
          ))}
        </select>

        {/* Custom chevron icon */}
        <div className="pointer-events-none absolute inset-y-0 right-3 flex items-center">
          <svg
            className="w-3.5 h-3.5 text-slate-400"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
            strokeWidth={2.5}
          >
            <path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" />
          </svg>
        </div>
      </div>
    </div>
  );
};

export default PriorityFilter;
