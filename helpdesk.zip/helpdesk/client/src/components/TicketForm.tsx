// components/TicketForm.tsx
// Controlled form for creating a new ticket — calls onSubmit with form data

import React, { useState } from "react";
import type { CreateTicketPayload, Priority } from "../types/ticket";

interface Props {
  onSubmit: (payload: CreateTicketPayload) => Promise<void>;
  isLoading: boolean;
}

// Empty form state
const INITIAL_STATE: CreateTicketPayload = {
  subject: "",
  description: "",
  priority: "Medium",
};

const PRIORITY_OPTIONS: Priority[] = ["Low", "Medium", "High"];

const PRIORITY_COLORS: Record<Priority, string> = {
  Low:    "text-emerald-400 border-emerald-500/40 bg-emerald-500/10",
  Medium: "text-amber-400   border-amber-500/40   bg-amber-500/10",
  High:   "text-red-400     border-red-500/40     bg-red-500/10",
};

const TicketForm: React.FC<Props> = ({ onSubmit, isLoading }) => {
  const [form, setForm] = useState<CreateTicketPayload>(INITIAL_STATE);
  const [errors, setErrors] = useState<Partial<CreateTicketPayload>>({});

  // ── Validation ───────────────────────────────
  const validate = (): boolean => {
    const newErrors: Partial<CreateTicketPayload> = {};
    if (!form.subject.trim())      newErrors.subject      = "Subject is required.";
    if (!form.description.trim())  newErrors.description  = "Description is required.";
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  // ── Handlers ─────────────────────────────────
  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
    if (errors[name as keyof typeof errors]) {
      setErrors((prev) => ({ ...prev, [name]: undefined }));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;
    await onSubmit(form);
    setForm(INITIAL_STATE); // reset on success
    setErrors({});
  };

  // ── Render ───────────────────────────────────
  return (
    <form onSubmit={handleSubmit} noValidate>
      <div className="space-y-5">

        {/* Subject */}
        <div>
          <label className="block text-xs font-semibold text-slate-400 uppercase tracking-widest mb-2">
            Subject <span className="text-red-400">*</span>
          </label>
          <input
            name="subject"
            type="text"
            value={form.subject}
            onChange={handleChange}
            placeholder="Brief summary of the issue…"
            maxLength={120}
            className={`
              w-full glass rounded-xl px-4 py-3 text-sm text-slate-100
              placeholder:text-slate-500 focus:outline-none focus:ring-2
              transition-all duration-150
              ${errors.subject
                ? "border-red-500/60 focus:ring-red-500/30"
                : "focus:ring-brand-500/40 hover:border-white/20"
              }
            `}
          />
          {errors.subject && (
            <p className="mt-1.5 text-xs text-red-400 flex items-center gap-1">
              <span>⚠</span> {errors.subject}
            </p>
          )}
        </div>

        {/* Description */}
        <div>
          <label className="block text-xs font-semibold text-slate-400 uppercase tracking-widest mb-2">
            Description <span className="text-red-400">*</span>
          </label>
          <textarea
            name="description"
            value={form.description}
            onChange={handleChange}
            placeholder="Describe the issue in detail…"
            rows={4}
            maxLength={1000}
            className={`
              w-full glass rounded-xl px-4 py-3 text-sm text-slate-100 resize-none
              placeholder:text-slate-500 focus:outline-none focus:ring-2
              transition-all duration-150
              ${errors.description
                ? "border-red-500/60 focus:ring-red-500/30"
                : "focus:ring-brand-500/40 hover:border-white/20"
              }
            `}
          />
          <div className="flex justify-between mt-1">
            {errors.description ? (
              <p className="text-xs text-red-400 flex items-center gap-1">
                <span>⚠</span> {errors.description}
              </p>
            ) : <span />}
            <span className="text-xs text-slate-600">
              {form.description.length}/1000
            </span>
          </div>
        </div>

        {/* Priority */}
        <div>
          <label className="block text-xs font-semibold text-slate-400 uppercase tracking-widest mb-2">
            Priority
          </label>
          <div className="flex gap-2">
            {PRIORITY_OPTIONS.map((p) => (
              <button
                key={p}
                type="button"
                onClick={() => setForm((prev) => ({ ...prev, priority: p }))}
                className={`
                  flex-1 py-2 rounded-xl text-xs font-semibold border transition-all duration-150
                  ${form.priority === p
                    ? PRIORITY_COLORS[p]
                    : "text-slate-500 border-white/10 bg-white/5 hover:border-white/20"
                  }
                `}
              >
                {p}
              </button>
            ))}
          </div>
        </div>

        {/* Submit */}
        <button
          type="submit"
          disabled={isLoading}
          className="
            w-full py-3 rounded-xl font-semibold text-sm text-white
            bg-brand-600 hover:bg-brand-500
            disabled:opacity-50 disabled:cursor-not-allowed
            transition-all duration-200 hover:shadow-lg hover:shadow-brand-600/25
            active:scale-[0.99] flex items-center justify-center gap-2
          "
        >
          {isLoading ? (
            <>
              <svg className="animate-spin w-4 h-4" viewBox="0 0 24 24" fill="none">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z" />
              </svg>
              Submitting…
            </>
          ) : (
            <>
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M12 4v16m8-8H4" />
              </svg>
              Submit Ticket
            </>
          )}
        </button>
      </div>
    </form>
  );
};

export default TicketForm;
