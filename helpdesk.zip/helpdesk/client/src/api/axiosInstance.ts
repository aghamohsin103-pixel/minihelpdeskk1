// api/axiosInstance.ts
// Centralised Axios instance — all API calls use this base config

import axios from "axios";

const api = axios.create({
  baseURL: "http://localhost:5000", // Backend base URL
  headers: {
    "Content-Type": "application/json",
  },
  timeout: 10000, // 10 second timeout
});

export default api;
