// types/ticket.ts
// Shared TypeScript types used across the frontend

export type Priority = "Low" | "Medium" | "High";
export type Status   = "Open" | "In Progress" | "Closed";

export interface Ticket {
  _id: string;
  ticketId: string;
  subject: string;
  description: string;
  priority: Priority;
  status: Status;
  createdAt: string; // ISO date string from MongoDB
}

// Shape for the create-ticket form
export interface CreateTicketPayload {
  subject: string;
  description: string;
  priority: Priority;
}
