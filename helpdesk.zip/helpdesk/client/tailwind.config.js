/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      fontFamily: {
        display: ["'DM Serif Display'", "Georgia", "serif"],
        body: ["'DM Sans'", "system-ui", "sans-serif"],
        mono: ["'DM Mono'", "monospace"],
      },
      colors: {
        slate: {
          950: "#0a0f1a",
        },
        brand: {
          50:  "#f0f7ff",
          100: "#dbeefe",
          200: "#bde0fd",
          300: "#90cafc",
          400: "#5baaf8",
          500: "#3b8bf4",
          600: "#2568e8",
          700: "#1d53d5",
          800: "#1e44ac",
          900: "#1e3c88",
        },
      },
    },
  },
  plugins: [],
};
